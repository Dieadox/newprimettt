
ENT.Type = "point"
ENT.Base = "base_point"
